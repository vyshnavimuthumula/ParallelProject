package com.cg.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import com.cg.bean.Bank;
import com.cg.dao.DatabaseImpl;

public class ServiceImpl implements Service {
	Scanner sc = new Scanner(System.in);
	DatabaseImpl db = new DatabaseImpl();
	@Override
	public void createAcc(Bank bank) {		
		String name;
		String phoneNo;
		double balance;
		int pin;
		
		System.out.println("Enter name:");
		name=sc.next();
		bank.setName(name);
		
		System.out.println("Enter Phone Number:");
		phoneNo=sc.next();
		bank.setPhoneNo(phoneNo);
		
		
		System.out.println("Enter amount:");
		balance=sc.nextInt();
		bank.setBalance(balance);		
		
		System.out.println("Enter pin:");
		pin = sc.nextInt();
		bank.setPin(pin);
		
		Random rand = new Random();
		int acc = rand.nextInt(1000);
		bank.setAccount(acc);	
		
		db.createAcc(bank);
	}

	@Override
	public double showBlc() {	
		int accNo;
		int pin;
		System.out.println("Enter account number");
		accNo=sc.nextInt();
		System.out.println("Enter pin");
		pin=sc.nextInt();
		
		List<Bank> blcList = db.getList();
		for(Bank blclist:blcList) {
			if((blclist.getAccount()==accNo)&&(blclist.getPin()==pin)) {
				System.out.println("Balance = "+blclist.getBalance());
				return blclist.getBalance();
			}
			
		}
		return 0;
	}

	@Override
	public double deposit() {
		int accNo;
		int pin;
		System.out.println("Enter account number");
		accNo=sc.nextInt();
		System.out.println("Enter pin");
		pin=sc.nextInt();
		
		List<Bank> blcList = db.getList();
		for(Bank blclist:blcList) {
			if((blclist.getAccount()==accNo)&&(blclist.getPin()==pin)) {
				double amount;
				System.out.println("Enter amount to deposit");
				amount = sc.nextInt();
				blclist.getTrans().add("Credited amount: "+amount);
				amount=blclist.getBalance()+amount;
				blclist.setBalance(amount);				
				System.out.println("Balance = "+blclist.getBalance());
				return blclist.getBalance();
			}			
		}
		return 0;
	}

	@Override
	public double withdraw() {
		int accNo;
		int pin;
		System.out.println("Enter account number");
		accNo=sc.nextInt();
		System.out.println("Enter pin");
		pin=sc.nextInt();
		
		List<Bank> blcList = db.getList();
		for(Bank blclist:blcList) {
			if((blclist.getAccount()==accNo)&&(blclist.getPin()==pin)) {
				double amount;
				System.out.println("Enter amount to withdraw");
				amount = sc.nextInt();
				blclist.getTrans().add("Debited amount: "+amount);
				amount=(blclist.getBalance())-amount;
				
				blclist.setBalance(amount);
				System.out.println("Balance = "+blclist.getBalance());
				return blclist.getBalance();
			}			
		}
		return 0;	
		
		
	}

	@Override
	public void fundTrans() {
		int accNo,pin,receiver;
		System.out.println("Enter account number");
		accNo=sc.nextInt();
		System.out.println("Enter pin");
		pin=sc.nextInt();
		System.out.println("Enter the account number to credit the money");
		receiver=sc.nextInt();
		
		List<Bank> customerList = db.getList();
		for(Bank acc1:customerList) {
			for(Bank acc2:customerList) {
				if((accNo==acc1.getAccount()) && receiver==acc2.getAccount()) {
					if((pin==acc1.getPin())) {
					int amount;
					System.out.println("Enter the amount to transfer");
					amount=sc.nextInt();
					acc2.setBalance(acc2.getBalance()+amount);
					acc1.setBalance(acc1.getBalance()-amount);
					System.out.println("Successfully transferred");
					}	
				}
				}
				
				}
			}
		
		

	@Override
	public List<String> printTrans() {
		int accNo;
		int pin;
		System.out.println("Enter account number");
		accNo=sc.nextInt();
		System.out.println("Enter pin");
		pin=sc.nextInt();
		
		List<Bank> blcList = db.getList();
		for(Bank blclist:blcList) {
			if((blclist.getAccount()==accNo)&&(blclist.getPin()==pin)) {
				System.out.println(blclist.getTrans());
			}			
		}
		
		return null;
	}

}
