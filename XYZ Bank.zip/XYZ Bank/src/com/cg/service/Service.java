package com.cg.service;

import java.util.List;

import com.cg.bean.Bank;


public interface Service {
	void createAcc(Bank bank);
	double showBlc();
	double deposit();
	double withdraw();
	void fundTrans();
	List<String> printTrans();
}
