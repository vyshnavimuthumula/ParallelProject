package com.cg.bean;

import java.util.ArrayList;
import java.util.List;

public class Bank {
	private String name;
	private String phoneNo;
	private int account;
	private int pin;
	private double balance;
	private List<String> trans = new ArrayList<String>();
	public Bank(String name, String phoneNo, int account,int pin, double balance) {
		this.name=name;
		this.phoneNo=phoneNo;
		this.account=account;
		this.pin=pin;
		this.balance=balance;		
	}
	public Bank()
	{
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public int getAccount() {
		return account;
	}
	public void setAccount(int account) {
		this.account = account;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public List<String> getTrans() {
		return trans;
	}
	public void setTrans(List<String> trans) {
		this.trans = trans;
	}
	@Override
	public String toString() {
		return "Bank [name=" + name + ", phoneNo=" + phoneNo + ", account=" + account + ", balance=" + balance + "]";
	}
	
}
