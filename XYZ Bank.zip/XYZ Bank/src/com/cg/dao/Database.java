package com.cg.dao;

public interface Database {

}
