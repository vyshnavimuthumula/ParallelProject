package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Bank;

public class DatabaseImpl{
	static ArrayList<Bank> list = new ArrayList<Bank>();
	static {
	Bank details_1 = new Bank("Monica","8919237529",11,1234,15648.0);
	Bank details_2 = new Bank("Laitha","7893068692",18,7895,8979464.0);
	Bank details_3 = new Bank("Ramya","7894561230",77,4546,15498.0);
	list.add(details_1);
	list.add(details_2);
	list.add(details_3);
	}
	Bank bank = new Bank();
	public void createAcc(Bank bank)
	{
		list.add(bank);
		System.out.println(bank);
	}

	public double showBlc() {
		return bank.getBalance();
	}
	
	public List<Bank> getList() {
		
		return list;
	}
	
	
}
