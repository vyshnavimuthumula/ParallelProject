package com.cg.presentation;

import java.util.Scanner;
import com.cg.bean.Bank;
import com.cg.service.ServiceImpl;

public class Main {
	public static void main(String args[])
	{

		int n;
		Scanner sc = new Scanner(System.in);
		while(true) {
		System.out.println("Welcome to XYZ Bank");
		System.out.println("1. Create account\n2. Show balance\n3. Deposit\n4. Withdraw\n5. Fund transaction\n6. Print Transaction\n7. Logout ");
		n=sc.nextInt();	
		Bank bank= new Bank();
		ServiceImpl service = new ServiceImpl();
		switch(n)
		{
		case 1: service.createAcc(bank);
				break;
		case 2: service.showBlc();
				break; 
		case 3: service.deposit();
				break;
		case 4: service.withdraw();
				break;
		case 5: service.fundTrans();
				break;
		case 6: service.printTrans();
				break;
		case 7:System.exit(0);
		default:System.out.println("Invalid option.");
		}
	}
}
}
