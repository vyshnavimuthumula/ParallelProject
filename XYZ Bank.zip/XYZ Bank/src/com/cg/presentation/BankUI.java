package com.cg.presentation;

import java.util.Random;
import java.util.Scanner;

import com.cg.bean.Bank;
import com.cg.service.ServiceImpl;

public class BankUI {

	Bank bank= new Bank();
	ServiceImpl service = new ServiceImpl();
	Scanner sc = new Scanner(System.in);
	public void register() {
		String name;
		String phoneNo;
		double balance;
		int pin;
		
		System.out.println("Enter name:");
		name=sc.next();
		bank.setName(name);
		
		System.out.println("Enter Phone Number:");
		phoneNo=sc.next();
		bank.setPhoneNo(phoneNo);
		
		
		System.out.println("Enter amount:");
		balance=sc.nextInt();
		bank.setBalance(balance);		
		
		System.out.println("Enter pin:");
		pin = sc.nextInt();
		bank.setPin(pin);
		
		Random rand = new Random();
		int acc = rand.nextInt(1000);
		bank.setAccount(acc);	
		
		service.createAcc(bank);
		
	}



}
